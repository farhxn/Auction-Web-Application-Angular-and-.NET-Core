using System.Data.Entity;
using AuctionWebApp.Data;
using AuctionWebApp.DTOs;
using AuctionWebApp.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AuctionWebApp.Controllers
{

  [Route("api/[controller]/[action]")]
  [ApiController]
  public class AuctionVehicleController : ControllerBase
  {
    private readonly DBContext dbContext;

    public AuctionVehicleController(DBContext dbContext)
    {
      this.dbContext = dbContext;
    }


    [AllowAnonymous]
    [HttpGet]
    public async Task<ActionResult> getVechileList()
    {
      ResponseDto responseDto = new ResponseDto();
      responseDto.data =  dbContext.auctionVehicles.ToList();
      return Ok(responseDto);
    }



    [Authorize]
    [HttpPost]
    public async Task<ActionResult> AddAuctionVechile(AuctionVehicle auctionVehicle)
    {
      ResponseDto responseDto = new ResponseDto();
      if (!ModelState.IsValid)
        return BadRequest(ModelState);

      try
      {
        dbContext.auctionVehicles.Add(auctionVehicle);
       int result = await dbContext.SaveChangesAsync();
        if (result > 0)
        {
          responseDto.message = "Auction vehicle registered successfully.";
          responseDto.data = auctionVehicle;
          return Ok(responseDto);
        }
        else
        {
          responseDto.isSuccess = false;
          responseDto.message = "Registration Failed";
          responseDto.data = "Unknown Errror Occured";
          return BadRequest(responseDto);
        }

      }
      catch (Exception ex) {
        responseDto.isSuccess = false;
        responseDto.message = "An error occurred while registering the vehicle.";
        responseDto.data = ex.Message; 
        return BadRequest(responseDto);
      }

    } 
  }
}
