namespace AuctionWebApp.DTOs
{
  public class AppSettings
  {
    public string JWTSecret { get; set; }
  }
}
