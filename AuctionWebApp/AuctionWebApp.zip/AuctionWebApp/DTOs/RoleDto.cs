namespace AuctionWebApp.DTOs
{
  public class RoleDto
  {
    public string name { get; set; }
  }
}
